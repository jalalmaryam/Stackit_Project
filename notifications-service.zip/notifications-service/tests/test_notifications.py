import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_post_warning_notification():
    """Test that a 'Warning' notification is forwarded"""
    response = client.post("/notifications", json={
        "Type": "Warning",
        "Name": "Backup Failure",
        "Description": "The backup failed due to a database problem"
    })
    assert response.status_code == 200
    assert response.json() == {"status": "forwarded"}


def test_post_info_notification():
    """Test that an 'Info' notification is ignored"""
    response = client.post("/notifications", json={
        "Type": "Info",
        "Name": "Quota Exceeded",
        "Description": "Compute Quota exceeded"
    })
    assert response.status_code == 200
    assert response.json() == {"status": "ignored"}


def test_get_forwarded_notifications():
    """Test that forwarded notifications can be retrieved"""
    # First, send a warning notification
    client.post("/notifications", json={
        "Type": "Warning",
        "Name": "Disk Space Low",
        "Description": "Less than 10% disk space remaining"
    })

    # Then check the forwarded list
    response = client.get("/notifications/forwarded")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    assert any(n["Type"] == "Warning" for n in data)
