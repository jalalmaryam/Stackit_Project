from fastapi import FastAPI
from .routes import router

app = FastAPI(title="Notification Service")

# include routes
app.include_router(router)
