# In-memory storage for notifications
notifications_store = []
forwarded_store = []
