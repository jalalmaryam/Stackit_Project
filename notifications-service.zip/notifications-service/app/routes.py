from fastapi import APIRouter
from .models import Notification
from .storage import notifications_store
from .messenger import forward_to_channel

router = APIRouter()

@router.post("/notifications")
def receive_notification(notification: Notification):
    data = notification.dict()
    notifications_store.append(data)

    if data["Type"].lower() == "warning":
        forward_to_channel(data)
        return {"status": "forwarded"}
    else:
        return {"status": "ignored"}

@router.get("/notifications/forwarded")
def get_forwarded():
    from .storage import forwarded_store
    return forwarded_store
