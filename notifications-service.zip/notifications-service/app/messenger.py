def forward_to_channel(notification: dict):
    """
    Fake messenger forwarder.
    In real-world, this could send to Slack, Teams, Discord, etc.
    For now, just print to console and save to forwarded_store.
    """
    from .storage import forwarded_store
    forwarded_store.append(notification)
    print(f"[Messenger] Forwarded notification: {notification['Name']}")
