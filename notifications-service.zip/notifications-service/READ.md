# Notifications Service

A REST API for receiving and filtering notifications, built with FastAPI.

## Features

- **POST** `/notifications` - Submit new notifications
- **GET** `/notifications/forwarded` - View forwarded warnings
- **GET** `/notifications/received` - View all received notifications
- **GET** `/health` - Service health check

## API Documentation

swagger - Interactive API docs available at: 
http://127.0.0.1:8000/docs

## Installation & Usage

### Run the Application
```bash
uvicorn app.main:app --reload

### Testing

bash

pytest -q

## Example Requests

### POST Notification

json

{
  "Type": "Warning",
  "Name": "Backup Failure",
  "Description": "Database problem"
}

### Successful Response

json

{
  "status": "forwarded",
  "detail": "Backup Failure"
}

### Info Notification (Ignored)

json

{
  "Type": "Info",
  "Name": "Daily Report",
  "Description": "System check completed"
}

## Development Workflow

1.  Start the server:
    
    bash
    
    uvicorn app.main:app --reload
    
2.  Access the interactive docs:  
    [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
    
3.  Test endpoints:
    
    -   POST  `/notifications`  with:
        
        -   "Type": "Warning" → shows "forwarded"
            
        -   "Type": "Info" → shows "ignored"
            
4.  Run tests:
    
    bash
    
    pytest -q